# Chess AI Web Application

A web-based chess game with an AI opponent built using Flask and Python.

## Features
- Play chess against an AI opponent
- Responsive web interface
- Configurable AI difficulty
- Move validation and legal move highlighting
- Game state tracking

## Prerequisites
- Python 3.8 or higher
- pip (Python package installer)

## Local Setup

1. Clone the repository:
```bash
git clone <your-repository-url>
cd chess-ai-web
```

2. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
```

3. Install dependencies:
```bash
pip install -r requirements.txt
```

4. Run the application:
```bash
python app.py
```

The application will be available at `http://localhost:5000`

## Deployment

### Option 1: Heroku

1. Install [Heroku CLI](https://devcenter.heroku.com/articles/heroku-cli)
2. Login to Heroku:
```bash
heroku login
```

3. Create a new Heroku app:
```bash
heroku create your-chess-app-name
```

4. Deploy:
```bash
git init
git add .
git commit -m "Initial commit"
git push heroku main
```

5. Scale the app:
```bash
heroku ps:scale web=1
```

### Option 2: PythonAnywhere

1. Create an account on [PythonAnywhere](https://www.pythonanywhere.com)
2. Upload your files using their file browser
3. Create a new web app:
   - Choose Flask framework
   - Python 3.8 or later
4. Set source code to `/home/yourusername/your-chess-app/wsgi.py`
5. Set working directory to `/home/yourusername/your-chess-app`
6. Update your WSGI configuration file

### Option 3: Railway.app

1. Create an account on [Railway](https://railway.app)
2. Install Railway CLI and login:
```bash
railway login
```

3. Initialize and deploy:
```bash
railway init
railway up
```

## Environment Variables

Set the following environment variables in production:
- `FLASK_ENV`: Set to 'production'
- `SECRET_KEY`: Your secret key for session management
- `PORT`: Port number (optional, defaults to 5000)

## Contributing

Feel free to submit issues and enhancement requests!

## License

[MIT License](LICENSE) 